$ ansible-galaxy init nginx-role 
$ cd nginx-role 
we need to register this role to get call from playbook 

once you have added playbook for installing Nginx inside Playbooks directory then jump to
Ansible/roles/nginx-role/tasks/main.yml

---
  - name: install nginx
    apt:
      name: nginx
      state: latest
  - name: install nginx
    service:
      name: nginx
      enabled: yes   

we can directly give file index.html as this is known to Ansible-galxy that it will present inside files folder

- name: deply web page
  copy:
    src = index.html
    dest = /var/www/html